# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

def get_str(id):
    return ADDON.getLocalizedString(id)

def get_dir_size(path):
    """Berechnet Größe mit Kodi-VFS (besser für Android)"""
    total = 0
    dirs, files = xbmcvfs.listdir(path)
    for f in files:
        stat = xbmcvfs.Stat(os.path.join(path, f))
        total += stat.st_size()
    for d in dirs:
        total += get_dir_size(os.path.join(path, d, ''))
    return total

def format_size(size):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024: return f"{size:.2f} {unit}"
        size /= 1024
    return f"{size:.2f} TB"

def run_cleaner():
    # 1. Bestätigung (ID 30001 aus deiner PO)
    if not xbmcgui.Dialog().yesno(ADDON_NAME, get_str(30001)):
        return

    cache_paths = ["special://temp/", "special://home/cache/"]
    
    # Vorher messen
    size_before = sum(get_dir_size(p) for p in cache_paths)

    # Löschvorgang mit Fortschrittsbalken (Wichtig für Fire Stick)
    pDialog = xbmcgui.DialogProgress()
    pDialog.create(ADDON_NAME, "Reinigung läuft...")

    for path in cache_paths:
        dirs, files = xbmcvfs.listdir(path)
        for f in files:
            xbmcvfs.delete(os.path.join(path, f))
    
    pDialog.close()
    
    # Nachher messen
    size_after = sum(get_dir_size(p) for p in cache_paths)

    # 2. Erfolg vermelden (ID 30002)
    # Wir nutzen eine Notification für ein moderneres Android-Feeling
    summary = f"Vorher: {format_size(size_before)} | Nachher: {format_size(size_after)}"
    xbmcgui.Dialog().ok(get_str(30002), summary)

if __name__ == '__main__':
    run_cleaner()

