# -*- coding: utf-8 -*-
import requests
import xbmcaddon
import xbmc

ADDON = xbmcaddon.Addon('script.module.vbrs.tools')

def resolve_domain(domain):
    """Löst eine Domain über DoH auf, falls aktiviert."""
    mode = ADDON.getSetting('dns_provider')
    if mode == "0" or not mode:
        return None

    providers = {
        "1": "https://cloudflare-dns.com/dns-query",
        "2": "https://dns.google/resolve",
        "3": "https://dns.quad9.net/dns-query"
    }
    
    url = providers.get(mode)
    params = {'name': domain, 'type': 'A'}
    headers = {'accept': 'application/dns-json'}

    try:
        r = requests.get(url, params=params, headers=headers, timeout=4)
        data = r.json()
        if 'Answer' in data:
            ip = data['Answer'][0]['data']
            xbmc.log(f"[VBRS-DNS] {domain} -> {ip} ({url})", xbmc.LOGINFO)
            return ip
    except Exception as e:
        xbmc.log(f"[VBRS-DNS] Fehler: {str(e)}", xbmc.LOGERROR)
    return None

