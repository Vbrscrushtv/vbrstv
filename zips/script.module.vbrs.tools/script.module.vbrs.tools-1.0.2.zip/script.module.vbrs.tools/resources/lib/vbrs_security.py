# -*- coding: utf-8 -*-
import requests
import xbmcaddon
import xbmc
import xbmcgui

ADDON = xbmcaddon.Addon('script.module.vbrs.tools')

def get_vpn_status():
    """Prüft die aktuelle IP-Adresse auf VPN/Hosting-Merkmale."""
    try:
        r = requests.get('http://ip-api.com/json/?fields=status,proxy,hosting,org,country', timeout=4)
        data = r.json()
        if data.get('status') == 'success':
            is_protected = data.get('proxy', False) or data.get('hosting', False)
            org = data.get('org', 'Unknown ISP')
            country = data.get('country', 'Unknown')
            status_info = f"{org} ({country})"
            return is_protected, status_info
    except:
        pass
    return False, "Unknown"

def check_vpn_and_warn():
    """Prüft VPN-Status basierend auf Addon-Einstellungen."""
    # Hauptschalter abfragen
    if ADDON.getSetting('vpn_check_enabled') == 'true':
        is_safe, info = get_vpn_status()
        
        if not is_safe:
            # Warn-Benachrichtigung (Strings aus strings.po)
            xbmcgui.Dialog().notification(
                ADDON.getLocalizedString(40020), 
                f"{ADDON.getLocalizedString(40021)} - {info}", 
                xbmcgui.NOTIFICATION_WARNING, 
                6000
            )
            
            # Harter Block, wenn "Nur Warnung" deaktiviert ist
            if ADDON.getSetting('vpn_warn_only') == 'false':
                xbmcgui.Dialog().ok(ADDON.getLocalizedString(40020), "VPN REQUIRED!")
                return False
    return True

