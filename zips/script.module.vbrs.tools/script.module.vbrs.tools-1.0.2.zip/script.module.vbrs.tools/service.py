# -*- coding: utf-8 -*-
import xbmc
from resources.lib import vbrs_security

if __name__ == '__main__':
    xbmc.log("[VBRS-Tools] Service gestartet", xbmc.LOGINFO)
    
    # Führt die VPN-Prüfung sofort beim Start von Kodi aus
    vbrs_security.check_vpn_and_warn()
    
    # Hält den Service im Hintergrund bereit (verhindert sofortiges Beenden)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
