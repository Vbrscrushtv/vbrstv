import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import zipfile
import xml.etree.ElementTree as ET

addon = xbmcaddon.Addon()
# WICHTIG: Nutze xbmcvfs für Pfadübersetzung in Kodi 21
ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
# Fallback für Android-Pfad Korrektur
if "primary/" in ADDONS_DIR:
    ADDONS_DIR = ADDONS_DIR.replace("primary/", "/storage/emulated/0/")

def get_export_path():
    path = addon.getSetting("export_path")
    if not path:
        return "/storage/emulated/0/Download/"
    return xbmcvfs.translatePath(path)

def zip_addon(addon_id):
    export_dir = get_export_path()
    
    # Sicherstellen, dass der Zielordner existiert
    if not xbmcvfs.exists(export_dir):
        xbmcvfs.mkdirs(export_dir)

    source_dir = os.path.join(ADDONS_DIR, addon_id)
    zip_path = os.path.join(export_dir, f"{addon_id}.zip")

    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, os.path.dirname(source_dir))
                    zipf.write(full_path, rel_path)
        return zip_path
    except Exception as e:
        xbmc.log(f"EXPORT ERROR: {str(e)}", xbmc.LOGERROR)
        return None

def main():
    dirs = xbmcvfs.listdir(ADDONS_DIR)[0]
    # Filtert System-Addons aus
    user_addons = [d for d in dirs if not d.startswith(('xbmc.', 'kodi.', 'resource.'))]
    
    choice = xbmcgui.Dialog().select("Addon zum Exportieren wählen", user_addons)
    if choice != -1:
        selected = user_addons[choice]
        progress = xbmcgui.DialogProgressBG()
        progress.create("Exportiere...", selected)
        
        result = zip_addon(selected)
        progress.close()
        
        if result:
            xbmcgui.Dialog().ok("Erfolg", f"Exportiert nach:\n{result}")
        else:
            xbmcgui.Dialog().ok("Fehler", "Schreibzugriff verweigert. Bitte Android-Berechtigungen prüfen!")

if __name__ == "__main__":
    main()

