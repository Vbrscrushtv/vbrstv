import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import zipfile
import traceback
import xml.etree.ElementTree as ET

addon = xbmcaddon.Addon()
ADDON_NAME = addon.getAddonInfo('name')

# WICHTIG: Nutze xbmcvfs für Pfadübersetzung in Kodi 21
ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
# Fallback für Android-Pfad Korrektur (Kodi liefert teils "primary/" statt echtem Pfad)
if "primary/" in ADDONS_DIR:
    ADDONS_DIR = ADDONS_DIR.replace("primary/", "/storage/emulated/0/")

# Builtin-/Systemsteine, die nie als "eigene Addons" exportiert werden sollen,
# selbst wenn "System-Addons anzeigen" aktiv ist (reine Laufzeit-Requirements).
CORE_RUNTIME_IDS = {"xbmc.python", "xbmc.gui", "xbmc.json", "xbmc.addon", "xbmc.core"}


def get_setting_bool(setting_id, default=False):
    try:
        return addon.getSettingBool(setting_id)
    except Exception:
        val = addon.getSetting(setting_id)
        return str(val).lower() == "true" if val else default


def get_export_path():
    path = addon.getSetting("export_path")
    if not path:
        path = "/storage/emulated/0/Download/"
    real_path = xbmcvfs.translatePath(path)
    # content://-URIs (Android Scoped Storage) kann zipfile/os nicht direkt beschreiben.
    if real_path.startswith("content://"):
        raise IOError(
            "Der gewählte Zielordner ist ein Android content://-Pfad und kann von "
            "diesem Addon nicht direkt beschrieben werden. Bitte einen klassischen "
            "Speicherpfad wie /storage/emulated/0/Download wählen."
        )
    return real_path


def is_system_addon(addon_id):
    """
    Namenskonventions-Heuristik – bewusst so, nicht als Notlösung:
    Kodi liefert an Skripte weder über addon.xml noch über die Python-API ein
    zuverlässiges "ist Systemaddon"-Flag. special://home/addons/ enthält neben
    eigenen Addons zudem aktualisierte Kopien mitgelieferter Komponenten
    (z.B. resource.language.*, Skin-Updates, inputstream.*), die hier ebenfalls
    ausgefiltert werden sollen.
    """
    if not xbmcvfs.exists(os.path.join(ADDONS_DIR, addon_id, "addon.xml")):
        return True
    return addon_id.startswith((
        "xbmc.", "kodi.", "resource.", "skin.",
        "screensaver.", "visualization.", "service.kodi.", "metadata.",
    ))


def get_dependencies(addon_id):
    """Liest <requires><import addon="..."/></requires> aus addon.xml."""
    addon_xml_path = os.path.join(ADDONS_DIR, addon_id, "addon.xml")
    deps = []
    if not xbmcvfs.exists(addon_xml_path):
        return deps
    try:
        f = xbmcvfs.File(addon_xml_path)
        content = f.read()
        f.close()
        root = ET.fromstring(content)
        requires = root.find("requires")
        if requires is not None:
            for imp in requires.findall("import"):
                dep_id = imp.get("addon")
                if dep_id and dep_id not in CORE_RUNTIME_IDS:
                    dep_path = os.path.join(ADDONS_DIR, dep_id)
                    if xbmcvfs.exists(dep_path + "/"):
                        deps.append(dep_id)
    except Exception:
        xbmc.log(f"[{ADDON_NAME}] Konnte Dependencies von {addon_id} nicht lesen:\n{traceback.format_exc()}",
                  xbmc.LOGWARNING)
    return deps


def get_addon_version(addon_id):
    addon_xml_path = os.path.join(ADDONS_DIR, addon_id, "addon.xml")
    try:
        f = xbmcvfs.File(addon_xml_path)
        content = f.read()
        f.close()
        root = ET.fromstring(content)
        return root.get("version", "")
    except Exception:
        return ""


def build_zip_name(addon_id):
    if get_setting_bool("zip_with_version"):
        version = get_addon_version(addon_id)
        if version:
            return f"{addon_id}-{version}.zip"
    return f"{addon_id}.zip"


def zip_single_addon_dir(addon_id, export_dir, progress=None, progress_offset=0.0, progress_span=100.0):
    """Packt genau EIN Addon-Verzeichnis in eine eigene, für sich installierbare ZIP-Datei."""
    source_dir = os.path.join(ADDONS_DIR, addon_id)

    all_files = []
    for root, dirs, files in os.walk(source_dir):
        for file in files:
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, ADDONS_DIR)
            all_files.append((full_path, rel_path))

    if not all_files:
        raise IOError(f"Keine Dateien für '{addon_id}' gefunden unter {ADDONS_DIR}")

    zip_path = os.path.join(export_dir, build_zip_name(addon_id))
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        total = len(all_files)
        for i, (full_path, rel_path) in enumerate(all_files):
            zipf.write(full_path, rel_path)
            if progress is not None:
                local_percent = ((i + 1) / total) * progress_span
                progress.update(int(progress_offset + local_percent), message=rel_path)

    return zip_path


def zip_addon(addon_id, progress=None, include_dependencies=True):
    """
    Exportiert ein Addon in den Export-Ordner.
    Bei include_dependencies=True bekommt JEDE Abhängigkeit eine EIGENE ZIP-Datei
    (statt alles in ein Archiv zu bündeln) - Kodis "Install from zip file" erwartet
    pro ZIP genau einen Addon-Ordner mit passender addon.xml an der Wurzel.
    Gibt (Liste der erzeugten ZIP-Pfade, Liste der gepackten Addon-IDs) zurück.
    """
    export_dir = get_export_path()
    if not xbmcvfs.exists(export_dir):
        xbmcvfs.mkdirs(export_dir)

    ids_to_pack = [addon_id]
    if include_dependencies:
        ids_to_pack.extend(get_dependencies(addon_id))

    created_zips = []
    total_ids = len(ids_to_pack)
    for idx, aid in enumerate(ids_to_pack):
        offset = (idx / total_ids) * 100.0
        span = 100.0 / total_ids
        zip_path = zip_single_addon_dir(aid, export_dir, progress=progress,
                                         progress_offset=offset, progress_span=span)
        created_zips.append(zip_path)

    return created_zips, ids_to_pack


def get_user_addons():
    dirs = xbmcvfs.listdir(ADDONS_DIR)[0]
    show_system = get_setting_bool("show_system_addons")
    if show_system:
        return sorted(dirs)
    return sorted(d for d in dirs if not is_system_addon(d))


def export_single(addon_id):
    progress = xbmcgui.DialogProgressBG()
    progress.create(f"{ADDON_NAME}: Exportiere...", addon_id)
    try:
        zip_paths, packed = zip_addon(addon_id, progress=progress)
        progress.close()
        message = "Exportiert:\n" + "\n".join(zip_paths)
        if len(packed) > 1:
            message += f"\n\n({len(packed) - 1} Abhängigkeit(en) als eigene ZIP-Datei(en))"
        xbmcgui.Dialog().ok("Erfolg", message)
    except Exception as e:
        progress.close()
        xbmc.log(f"[{ADDON_NAME}] EXPORT ERROR ({addon_id}):\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Export fehlgeschlagen:\n{str(e)}")


def export_batch(addon_ids):
    progress = xbmcgui.DialogProgress()
    progress.create(f"{ADDON_NAME}: Batch-Export", "Starte...")
    failed = []
    try:
        for idx, addon_id in enumerate(addon_ids):
            if progress.iscanceled():
                break
            percent = int((idx / len(addon_ids)) * 100)
            progress.update(percent, f"Exportiere: {addon_id}")
            try:
                zip_addon(addon_id, progress=None)
            except Exception:
                xbmc.log(f"[{ADDON_NAME}] Batch-Export Fehler bei {addon_id}:\n{traceback.format_exc()}",
                          xbmc.LOGERROR)
                failed.append(addon_id)
        progress.close()
    finally:
        progress.close()

    if failed:
        xbmcgui.Dialog().ok("Batch-Export beendet",
                             f"{len(addon_ids) - len(failed)} erfolgreich, "
                             f"{len(failed)} fehlgeschlagen:\n" + ", ".join(failed))
    else:
        xbmcgui.Dialog().ok("Batch-Export beendet", f"{len(addon_ids)} Addon(s) erfolgreich exportiert.")


def main():
    try:
        user_addons = get_user_addons()
    except Exception:
        xbmc.log(f"[{ADDON_NAME}] Konnte Addon-Verzeichnis nicht lesen:\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", "Addon-Verzeichnis konnte nicht gelesen werden.")
        return

    if not user_addons:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine exportierbaren Addons gefunden.")
        return

    if get_setting_bool("batch_export"):
        selected_indices = xbmcgui.Dialog().multiselect(
            f"Addons zum Exportieren wählen ({len(user_addons)} verfügbar)",
            user_addons
        )
        # None = Dialog abgebrochen, [] = OK ohne Auswahl -> in beiden Fällen nichts tun.
        if not selected_indices:
            return
        selected_addons = [user_addons[i] for i in selected_indices]
        export_batch(selected_addons)
        return

    choice = xbmcgui.Dialog().select("Addon zum Exportieren wählen", user_addons)
    if choice != -1:
        export_single(user_addons[choice])


if __name__ == "__main__":
    main()

