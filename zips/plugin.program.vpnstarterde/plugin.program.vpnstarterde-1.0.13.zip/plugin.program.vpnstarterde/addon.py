# -*- coding: utf-8 -*-
import xbmcaddon, xbmcgui, xbmc
import os, urllib.request, re

ADDON = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()

# Zielordner + Dateien
DOWNLOAD_DIR = "/storage/emulated/0/Download/Vpnstarter"
OVPN_PATH = os.path.join(DOWNLOAD_DIR, "config.ovpn")
AUTH_PATH = os.path.join(DOWNLOAD_DIR, "auth.txt")

# ----- Einstellungen (neuer Direkt-Download-Default) -----
# Dein FILE_ID = 15FBoAdfyJXUwFYChe8XkhTdtYvNnCQJ4
OVPN_URL = ADDON.getSetting('ovpn_url') or \
           "https://drive.usercontent.google.com/uc?id=15FBoAdfyJXUwFYChe8XkhTdtYvNnCQJ4&export=download"
VPN_USER = ADDON.getSetting('vpn_user') or "Banana"
VPN_PASS = ADDON.getSetting('vpn_pass') or "Banana"
VPN_PACKAGE = ADDON.getSetting('vpn_package') or "com.lonelycatgames.Xplore"  # X-plore Dateimanager

def notify(msg, level=xbmcgui.NOTIFICATION_INFO, ms=4000):
    DIALOG.notification("VPN Starter DE", msg, level, ms)

def ensure_dir(path):
    try:
        os.makedirs(path, exist_ok=True)
    except Exception as e:
        notify("Ordnerfehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmc.log("VPNStarterDE ensure_dir error: %s" % e, xbmc.LOGERROR)

# ---- Google-Drive-URL -> Direkt-Download umwandeln ----
def gdrive_direct_link(url: str) -> str:
    # /file/d/<ID>/...
    m = re.search(r"drive\.google\.com\/file\/d\/([^\/\?\#]+)", url)
    if m:
        fid = m.group(1)
        return f"https://drive.usercontent.google.com/uc?id={fid}&export=download"
    # ...?id=<ID> oder &id=<ID>
    m = re.search(r"[?&]id=([a-zA-Z0-9_-]+)", url)
    if m:
        fid = m.group(1)
        return f"https://drive.usercontent.google.com/uc?id={fid}&export=download"
    return url

def is_html(data: bytes, headers) -> bool:
    ct = headers.get('Content-Type', '').lower()
    if 'text/html' in ct:
        return True
    head = data[:200].lstrip()
    return head.startswith(b'<!DOCTYPE html') or head.startswith(b'<html')

def download(url, dest):
    try:
        url = gdrive_direct_link(url)  # <- hier wird dein /file/d/.../view Link korrigiert
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 Kodi-VpnStarterDE"})
        with urllib.request.urlopen(req) as r:
            data = r.read()
            if is_html(data, r.headers):
                raise RuntimeError("Die URL liefert HTML (vermutlich Drive-Ansichtsseite). Verwende uc?id=...&export=download.")
        with open(dest, "wb") as f:
            f.write(data)
        return True
    except Exception as e:
        notify("Download-Fehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmc.log("VPNStarterDE download error: %s" % e, xbmc.LOGERROR)
        return False

def write_auth(user, pwd, dest):
    try:
        with open(dest, "w", encoding="utf-8") as f:
            f.write(user + "\n" + pwd)
        return True
    except Exception as e:
        notify("Auth-Schreibfehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmc.log("VPNStarterDE auth write error: %s" % e, xbmc.LOGERROR)
        return False

# Ablauf
ensure_dir(DOWNLOAD_DIR)
ok1 = download(OVPN_URL, OVPN_PATH)
ok2 = write_auth(VPN_USER, VPN_PASS, AUTH_PATH) if ok1 else False

if ok1 and ok2:
    notify("OVPN & auth.txt bereit in Download/Vpnstarter. Öffne App…")
else:
    notify("Fehler – Details im Log.", xbmcgui.NOTIFICATION_ERROR, 6000)

# Android-App starten (Default: X-plore Dateimanager)
try:
    xbmc.executebuiltin("StartAndroidActivity(%s)" % VPN_PACKAGE)
except Exception as e:
    notify("Start fehlgeschlagen: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
    xbmc.log("VPNStarterDE start app error: %s" % e, xbmc.LOGERROR)
