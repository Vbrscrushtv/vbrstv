import xbmc
import xbmcgui
import xbmcvfs
import os

def run_vbrs_tuning():
    dialog = xbmcgui.Dialog()
    
    # Hauptmenü für VBRSTuning
    options = ["Optimierung anwenden", "Optimierung entfernen (Standard)", "Abbrechen"]
    selection = dialog.select("VBRSTuning - Hauptmenü", options)

    # Pfade definieren
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    file_path = os.path.join(userdata_path, 'advancedsettings.xml')
    backup_path = file_path + ".bak"

    # OPTION 1: Optimierung anwenden
    if selection == 0:
        xml_content = """<advancedsettings>
  <cache>
    <buffermode>1</buffermode>
    <memorysize>139460608</memorysize>
    <readfactor>20</readfactor>
  </cache>
</advancedsettings>"""

        try:
            if os.path.exists(file_path):
                if os.path.exists(backup_path): os.remove(backup_path)
                os.rename(file_path, backup_path)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(xml_content)
            
            dialog.ok("VBRSTuning", "Optimierung wurde erfolgreich aktiviert!\nBitte Kodi jetzt NEU STARTEN.")
        except Exception as e:
            dialog.notification("Fehler", str(e), xbmcgui.NOTIFICATION_ERROR)

    # OPTION 2: Deaktivieren / Entfernen
    elif selection == 1:
        if not os.path.exists(file_path):
            dialog.ok("VBRSTuning", "Keine aktive Optimierung gefunden.")
            return

        if dialog.yesno("VBRSTuning", "Möchtest du die Puffer-Optimierung wirklich entfernen und die Standardwerte von Kodi wiederherstellen?"):
            try:
                os.remove(file_path)
                # Falls ein Backup existiert, dieses wiederherstellen
                if os.path.exists(backup_path):
                    os.rename(backup_path, file_path)
                    msg = "Die Datei wurde auf den Stand vor dem Tuning zurückgesetzt."
                else:
                    msg = "Die Datei wurde gelöscht. Kodi nutzt nun wieder Standardwerte."
                
                dialog.ok("VBRSTuning", f"Erfolgreich deaktiviert!\n{msg}\nBitte Kodi NEU STARTEN.")
            except Exception as e:
                dialog.notification("Fehler", str(e), xbmcgui.NOTIFICATION_ERROR)

    # OPTION 3 oder Abbruch
    else:
        return

if __name__ == '__main__':
    run_vbrs_tuning()

