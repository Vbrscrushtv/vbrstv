# -*- coding: utf-8 -*- 
import xbmcaddon, xbmcgui, xbmc
import os, urllib.request

ADDON = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()

# ===== ZIELORDNER =====
DOWNLOAD_DIR = "/storage/emulated/0/Download/Vpnstarter"
OVPN_PATH = os.path.join(DOWNLOAD_DIR, "config.ovpn")
AUTH_PATH = os.path.join(DOWNLOAD_DIR, "auth.txt")

# ===== VPN URLS =====
OVPN_MAIN = ADDON.getSetting('ovpn_url')
OVPN_2 = ADDON.getSetting('ovpn_url_2')
OVPN_3 = ADDON.getSetting('ovpn_url_3')

# ===== ZUGANGSDATEN =====
VPN_USER = ADDON.getSetting('vpn_user')
VPN_PASS = ADDON.getSetting('vpn_pass')
VPN_PACKAGE = ADDON.getSetting('vpn_package') or "com.lonelycatgames.Xplore"

def notify(msg, level=xbmcgui.NOTIFICATION_INFO, ms=4000):
    DIALOG.notification("VPN Starter", msg, level, ms)

def ensure_dir(path):
    try:
        os.makedirs(path, exist_ok=True)
    except Exception as e:
        notify("Ordnerfehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmc.log("VPNStarter ensure_dir error: %s" % e, xbmc.LOGERROR)

def download(url, dest):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 Kodi-VpnStarter"})
        with urllib.request.urlopen(req) as r, open(dest, "wb") as f:
            f.write(r.read())
        return True
    except Exception as e:
        notify("Download-Fehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmc.log("VPNStarter download error: %s" % e, xbmc.LOGERROR)
        return False

def write_auth(user, pwd, dest):
    try:
        with open(dest, "w", encoding="utf-8") as f:
            f.write(user + "\n" + pwd)
        return True
    except Exception as e:
        notify("Auth-Schreibfehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmc.log("VPNStarter auth write error: %s" % e, xbmc.LOGERROR)
        return False

# ===== VPN AUSWAHLMENÜ =====
labels = ["Main VPN"]
urls = [OVPN_MAIN]

if OVPN_2:
    labels.append("Option 2")
    urls.append(OVPN_2)

if OVPN_3:
    labels.append("Option 3")
    urls.append(OVPN_3)

idx = DIALOG.select("VPN auswählen", labels)

if idx == -1:
    quit()

OVPN_URL = urls[idx]

# ===== ABLAUF =====
ensure_dir(DOWNLOAD_DIR)

ok1 = download(OVPN_URL, OVPN_PATH)
ok2 = write_auth(VPN_USER, VPN_PASS, AUTH_PATH) if ok1 else False

if ok1 and ok2:
    notify("OVPN & auth.txt bereit in Download/Vpnstarter. Öffne X-plore…")
else:
    notify("Fehler – Details im Log.", xbmcgui.NOTIFICATION_ERROR, 6000)

# ===== X-PLORE STARTEN =====
try:
    xbmc.executebuiltin("StartAndroidActivity(%s)" % VPN_PACKAGE)
except Exception as e:
    notify("Start fehlgeschlagen: %s" % e, xbmcgui.NOTIFICATION_ERROR, 6000)
    xbmc.log("VPNStarter start app error: %s" % e, xbmc.LOGERROR)
